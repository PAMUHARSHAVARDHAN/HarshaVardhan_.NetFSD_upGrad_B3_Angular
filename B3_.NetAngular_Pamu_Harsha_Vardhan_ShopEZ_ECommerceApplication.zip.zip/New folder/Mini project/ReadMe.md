# 🛒 ShopEZ – E-Commerce Frontend Application

##  Project Overview
ShopEZ is a frontend prototype of an e-commerce web application built using modern web technologies.  
It allows users to browse products, view product details, manage a shopping cart, and simulate a checkout process.

This project is fully client-side and uses JSON data and LocalStorage for data handling.

---

##  Features

###  Home Page
- Displays featured products
- Navigation bar and footer
- Responsive UI

###  Products Page
- Displays all products in grid layout
- Product image, name, price
- View and Add to Cart buttons

###  Product Details Page
- Shows detailed product information
- Add to Cart functionality

###  Cart Page
- View added products
- Quantity handling
- Remove items
- Total price calculation

###  Checkout Page
- Order summary
- User details form
- Order simulation

---

##  Technologies Used

- HTML5
- CSS3
- JavaScript (ES6)
- Bootstrap 5
- jQuery
- LocalStorage
- JSON

---

## Project Structure
ShopEZ-Frontend
│
├── index.html
├── products.html
├── product-details.html
├── cart.html
├── checkout.html
│
├── css
│ └── products.css
│
├── js
│ ├── products.js
│ ├── product-details.js
│ ├── cart.js
│ ├── checkout.js
│ └── common.js
│
├── json
│ └── data.json
│
├── images
│
└── lib

---

##  How to Run the Project

1. Download or clone the project
2. Open the project folder in VS Code
3. Run using **Live Server**
4. Open `index.html`

---

##  Key Concepts Implemented

- Dynamic content rendering using JavaScript
- Modular JavaScript (common.js)
- LocalStorage for cart persistence
- jQuery for DOM manipulation and events
- Responsive design using Bootstrap
- JSON-based data handling

---

##  Application Flow
Home → Products → Product Details → Add to Cart → Cart → Checkout


---

##  Functional Highlights

- Add to cart with quantity support
- Remove one item from cart
- Dynamic total calculation
- Checkout form validation
- Cart persistence using LocalStorage

---

##  Important Notes

- No backend or payment integration (simulation only)
- Requires Live Server for JSON fetching
- Ensure correct file paths

---

##  Future Enhancements

- Product search and filtering
- Cart item quantity update (+ / - buttons)
- User authentication
- Payment gateway integration
- Order confirmation page

---

##  Author

**Pamu Harsha Vardhan**

---

##  License

This project is for educational purposes only.