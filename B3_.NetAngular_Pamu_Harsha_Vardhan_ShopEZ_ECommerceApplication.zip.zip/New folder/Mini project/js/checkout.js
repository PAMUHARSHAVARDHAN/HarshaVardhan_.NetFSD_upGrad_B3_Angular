// ================= PAGE LOAD =================
$(document).ready(function () {
    loadCheckout();
});


// ================= LOAD CHECKOUT =================
function loadCheckout() {
    let cart = getCart(); // from common.js

    // Empty cart → redirect
    if (cart.length === 0) {
        alert("Your cart is empty!");
        window.location.href = "products.html";
        return;
    }

    $.getJSON("json/data.json")
        .done(function (products) {

            let html = "";
            let total = 0;

            cart.forEach(item => {
                let product = products.find(p => p.id === item.id);

                if (product) {
                    let itemTotal = product.price * item.qty;
                    total += itemTotal;

                    html += `
                        <div class="border rounded p-2 mb-2">
                            <h6>${product.name}</h6>
                            <p>Qty: ${item.qty}</p>
                            <p class="text-success">₹${itemTotal}</p>
                        </div>
                    `;
                }
            });

            $("#checkoutItems").html(html);
            $("#checkoutTotal").text(total);

        })
        .fail(function () {
            $("#checkoutItems").html("<p class='text-danger'>Failed to load data</p>");
        });
}


// ================= FORM SUBMIT =================
$("#checkoutForm").submit(function (e) {
    e.preventDefault();

    let name = $("#name").val().trim();
    let email = $("#email").val().trim();
    let address = $("#address").val().trim();

    // Basic validation
    if (!name || !email || !address) {
        alert("Please fill all details");
        return;
    }

    alert("Order placed successfully! 🎉");

    clearCart(); // from common.js

    window.location.href = "products.html";
});