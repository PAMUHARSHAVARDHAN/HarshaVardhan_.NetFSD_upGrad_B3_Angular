// ================= GET PRODUCT ID =================
function getProductId() {
    const params = new URLSearchParams(window.location.search);
    return parseInt(params.get("id"));
}


// ================= LOAD PRODUCT DETAILS =================
async function loadProductDetails() {
    const container = document.getElementById('productDetails');

    // Loading UI
    container.innerHTML = "<p class='text-center'>Loading product...</p>";

    const productId = getProductId();

    // Handle invalid ID
    if (!productId) {
        container.innerHTML = "<p class='text-danger text-center'>Invalid product ID</p>";
        return;
    }

    try {
        const response = await fetch('json/data.json');
        const products = await response.json();

        const product = products.find(p => p.id === productId);

        if (!product) {
            container.innerHTML = "<h3 class='text-center'>Product not found</h3>";
            return;
        }

        container.innerHTML = `
            <div class="col-md-6">
                <img src="${product.image}" 
                     class="product-img rounded shadow" 
                     style="height:400px; object-fit:contain;">
            </div>

            <div class="col-md-6 d-flex flex-column justify-content-center">
                <h2>${product.name}</h2>

                <p class="text-muted">${product.description}</p>

                <h4 class="text-success fw-bold">₹${product.price}</h4>

                <button class="btn btn-primary mt-3"
                        onclick="addToCart(${product.id})">
                    Add to Cart
                </button>
            </div>
        `;

    } catch (error) {
        console.error("Error:", error);

        container.innerHTML = `
            <p class="text-danger text-center">
                Failed to load product details
            </p>
        `;
    }
}


// ================= INITIALIZE =================
loadProductDetails();