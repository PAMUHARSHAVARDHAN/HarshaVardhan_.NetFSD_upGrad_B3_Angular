// ================= PAGE LOAD =================
$(document).ready(function () {
    loadCart();
});


// ================= LOAD CART =================
function loadCart() {
    let cart = getCart(); // from common.js

    // Empty cart
    if (cart.length === 0) {
        $("#cartItems").html("<h4 class='text-center'>Cart is empty</h4>");
        $("#cartTotal").text(0);

        $("#checkoutBtn").prop("disabled", true).addClass("disabled");
        return;
    }

    // Fetch products
    $.getJSON("json/data.json")
        .done(function (products) {

            let html = "";
            let total = 0;

            cart.forEach(item => {
                let product = products.find(p => p.id === item.id);

                if (product) {
                    let itemTotal = product.price * item.qty;
                    total += itemTotal;

                    html += `
                        <div class="col-md-4">
                            <div class="card shadow-sm">
                                <img src="${product.image}" 
                                     style="height:200px; object-fit:contain;">

                                <div class="card-body text-center">
                                    <h5>${product.name}</h5>
                                    <h6 class="text-success">₹${product.price}</h6>

                                    <p>Quantity: ${item.qty}</p>
                                    <p>Total: ₹${itemTotal}</p>

                                    <button class="btn btn-danger remove-btn" 
                                            data-id="${item.id}">
                                        Remove One
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }
            });

            $("#cartItems").html(html);
            $("#cartTotal").text(total);

            $("#checkoutBtn").prop("disabled", false).removeClass("disabled");

        })
        .fail(function () {
            $("#cartItems").html("<p class='text-danger text-center'>Failed to load cart</p>");
        });
}


// ================= REMOVE ITEM =================
$(document).on("click", ".remove-btn", function () {
    let id = $(this).data("id");

    removeFromCart(id); // from common.js

    loadCart();
});


// ================= CHECKOUT BUTTON =================
$("#checkoutBtn").click(function () {
    if (!$(this).prop("disabled")) {
        window.location.href = "checkout.html";
    }
});