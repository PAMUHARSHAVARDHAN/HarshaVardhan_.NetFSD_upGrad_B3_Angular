// ================= LOAD PRODUCTS =================
async function loadProducts() {
    const container = document.getElementById('productContainer');

    // Loading UI
    container.innerHTML = "<p class='text-center'>Loading products...</p>";

    try {
        const response = await fetch('json/data.json');
        const products = await response.json();

        displayProducts(products);

    } catch (error) {
        console.error("Error loading products:", error);

        container.innerHTML = `
            <p class="text-center text-danger">
                Failed to load products. Please try again.
            </p>
        `;
    }
}


// ================= DISPLAY PRODUCTS =================
function displayProducts(products) {
    const container = document.getElementById('productContainer');

    let html = "";

    products.forEach(product => {
        html += `
            <div class="col-md-4 col-sm-6">
                <div class="card product-card shadow-sm h-100">
                    
                    <img src="${product.image}" 
                         class="card-img-top" 
                         style="height:200px; object-fit:contain;">

                    <div class="card-body d-flex flex-column text-center">
                        <h5>${product.name}</h5>

                        <h6 class="text-success fw-bold">
                            ₹${product.price}
                        </h6>

                        <div class="mt-auto d-flex gap-2">
                            
                            <!-- View Button -->
                            <a href="product-details.html?id=${product.id}" 
                               class="btn btn-outline-primary w-50">
                                View
                            </a>

                            <!-- Add to Cart -->
                            <button class="btn btn-primary w-50" 
                                    onclick="addToCart(${product.id})">
                                Add
                            </button>

                        </div>
                    </div>

                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}


// ================= INITIALIZE =================
loadProducts();