/* =========================
   COMMON.JS (SHARED MODULE)
========================= */


// ================= GET CART =================
function getCart() {
    return JSON.parse(localStorage.getItem("cart")) || [];
}


// ================= SAVE CART =================
function saveCart(cart) {
    localStorage.setItem("cart", JSON.stringify(cart));
}


// ================= ADD TO CART =================
function addToCart(id) {
    let cart = getCart();

    let existing = cart.find(item => item.id === id);

    if (existing) {
        existing.qty += 1;
    } else {
        cart.push({ id: id, qty: 1 });
    }

    saveCart(cart);

    alert("Product added to cart!");
}


// ================= REMOVE ONE ITEM =================
function removeFromCart(id) {
    let cart = getCart();

    let item = cart.find(p => p.id === id);

    if (item) {
        item.qty -= 1;

        if (item.qty <= 0) {
            cart = cart.filter(p => p.id !== id);
        }
    }

    saveCart(cart);
}


// ================= CLEAR CART =================
function clearCart() {
    localStorage.removeItem("cart");
}


// ================= GET PRODUCT BY ID =================
function getProductById(products, id) {
    return products.find(p => p.id === id);
}


// ================= CALCULATE TOTAL =================
function calculateTotal(cart, products) {
    let total = 0;

    cart.forEach(item => {
        let product = products.find(p => p.id === item.id);

        if (product) {
            total += product.price * item.qty;
        }
    });

    return total;
}